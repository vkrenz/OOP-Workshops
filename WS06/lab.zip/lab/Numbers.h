#ifndef SDDS_NUMBERS_H_
#define SDDS_NUMBERS_H_
#include <iostream>
namespace sdds {
    const int MAX_FILE_NAME = 255;

    class Numbers {
        // Private Vars
        double* collection;
        char file_name[MAX_FILE_NAME + 1];
        unsigned int collection_size;
        bool is_original;
        bool has_added_number;
        // Private Member Funcs
        unsigned int countLines(const char* filename);
        void sort(double* collectionPtr, unsigned int size);
        void setEmpty();
        bool load();
    public:
        // One Argument Constructor
        Numbers(const char* filename);
        // Default Constructor
        Numbers();
        // Copy Constructor
        Numbers(const Numbers& other);
        // Copy Assignment Operator
        Numbers& operator=(const Numbers& other);
        // Destructor
        ~Numbers();
        
   };

}
#endif // !SDDS_NUMBERS_H_

