#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include "Numbers.h"
using namespace std;
namespace sdds {
   void Numbers::sort(double* nums, unsigned int size) {
      unsigned int i, j;
      double temp;
      for(i = size - 1; size && i > 0; i--) {
         for(j = 0; j < i; j++) {
            if(nums[j] > nums[j + 1]) {
               temp = nums[j];
               nums[j] = nums[j + 1];
               nums[j + 1] = temp;
            }
         }
      }
   }

   unsigned int Numbers::countLines(const char* filename) { /**/
      unsigned int lines = 0u;
      ifstream nums(filename);
      while(nums) {
         lines += (nums.get() == '\n');
      }
      return lines;
   }

   void Numbers::setEmpty() {

   }

   bool Numbers::load() {
       // Delete current collection
       delete[] collection;
       collection = nullptr;
       collection_size = 0;

        // Get the number of lines in the file
       int lines = countLines(file_name);

       // If the file is not empty, then allocate memory
       if (lines > 0) {
           collection = new double[lines];

           // Create an instance of ifstream
           ifstream fin(file_name);

           // Keep reading double values from the file into the elements of the Collection
           int count = 0;
           while (fin.good()) {
               if (count == lines) {
                   // If there's more values counted than there are lines, the file is corrupted
                   cerr << "Error: File is corrupted" << endl;
                   setEmpty();
                   return false;
               }
               fin >> collection[count];
               count++;
           }

           // If the number of lines and the number of successful reads match, then set the Collection size and original flag
           if (count == lines) {
               collection_size = count;
               is_original = true;
               return true;
           }
           else {
               // If they do not match then the file is corrupted
               cerr << "Error: File is corrupted" << endl;
               setEmpty();
               return false;
           }
       }
       else {
           // If the file is empty, then set the object back to an empty state
           setEmpty();
           return false;
       }
   }

   Numbers::Numbers(const char* filename) : collection(nullptr), collection_size(0), is_original(true), has_added_number(false) {
       strncpy(file_name, filename, sizeof(file_name));
       file_name[sizeof(file_name) - 1] = '\0';
       load();
   }

   Numbers::Numbers() : collection(nullptr), collection_size(0), is_original(true), has_added_number(false) {
       file_name[0] = '\0';
   }

   Numbers::Numbers(const Numbers& other) : collection(nullptr), collection_size(other.collection_size), is_original(false), has_added_number(false) {
       strncpy(file_name, other.file_name, sizeof(file_name));
       file_name[sizeof(file_name) - 1] = '\0';
       *this = other;
   }

   Numbers& Numbers::operator=(const Numbers& other) {
       if (this != &other) {
           save();
           delete[] collection;
           collection = nullptr;
           collection_size = 0;
           is_original = false;
           if (other.collection_size > 0) {
               collection = new double[other.collection_size];
               memcpy(collection, other.collection, other.collection_size * sizeof(double));
               collection_size = other.collection_size;
           }
       }
       return *this;
   }

   Numbers::~Numbers() {
       save();
       delete[] collection;
   }
}